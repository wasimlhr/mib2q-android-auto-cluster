#!/bin/sh
# MU1201 v5 KakaoNavi cockpit dropout hotfix.
#
# With no marker this script is read-only.  An action requires exactly one
# marker on the SD-card root:
#   kakao_dropout_fix_install
#   kakao_dropout_fix_remove
# Every run also copies the runtime logs (including the Java log /tmp/sq5_aa.log)
# to mib2q-aa-logs/ on the SD card.
set -u
PATH=/proc/boot:/bin:/usr/bin:/usr/sbin:/sbin:/mnt/app/armle/bin:/mnt/app/armle/usr/bin
export PATH
unset LD_PRELOAD

case $0 in */*) MOD=${0%/*} ;; *) MOD=. ;; esac
MOD=$(cd "$MOD" && pwd) || exit 1
PAYLOAD=$MOD/kakao-dropout-fix
TEST_ROOT=${KAKAO_DROPOUT_FIX_ROOT:-}

# M.I.B. may launch on RCC.  The HMI/JAR and installed v5 profile live on MMX.
if [ -z "$TEST_ROOT" ] && [ ! -d /mnt/app/eso/hmi/lsd ] && [ -d /net/mmx/mnt/app/eso/hmi/lsd ]; then
    exec on -f mmx /bin/sh "$MOD/custom.sh" "$@"
fi

rooted() { if [ -n "$TEST_ROOT" ]; then echo "$TEST_ROOT$1"; else echo "$1"; fi; }
SD=$(rooted /fs/sda0)
[ -d "$SD" ] || SD=$(rooted /net/mmx/fs/sda0)
BASE=$(rooted /mnt/app/root/sq5_android_auto)
PROFILE=$BASE/profile.id
JAR=$(rooted /mnt/app/eso/hmi/lsd/jars/mib2q_android_auto_cluster.jar)
BACKUP_DIR=$BASE/kakao-dropout-fix-backup
BACKUP=$BACKUP_DIR/mib2q_android_auto_cluster.jar
NEW=$PAYLOAD/mib2q_android_auto_cluster.jar
LOG=$SD/kakao-dropout-fix-status.txt
# cksum of the JAR installed by the MU1201 v5 pilot card, and of the withdrawn hotfix v1
V5_JAR_SUM="617051911 309303"
V1_JAR_SUM="3310442263 309579"

sum_of() { set -- $(cksum "$1" 2>/dev/null); echo "${1:-0} ${2:-0}"; }
fail() { echo "FAILED: $*"; exit 1; }
remount_rw() { [ -n "$TEST_ROOT" ] || mount -uw "$1"; }
remount_ro() { [ -n "$TEST_ROOT" ] || mount -ur "$1" 2>/dev/null; }
sync_all() { [ -n "$TEST_ROOT" ] || sync; }

put() {
    src=$1; dst=$2; mode=$3; tmp=$dst.kakao-new.$$
    cp -p "$src" "$tmp" || return 1
    chmod "$mode" "$tmp" || { rm -f "$tmp"; return 1; }
    [ "$(sum_of "$src")" = "$(sum_of "$tmp")" ] || { rm -f "$tmp"; return 1; }
    mv -f "$tmp" "$dst"
}

verify_payload() {
    [ -f "$NEW" ] || fail "missing payload JAR"
    [ -f "$PAYLOAD/manifest.cksum" ] || fail "missing payload manifest"
    read crc bytes name extra < "$PAYLOAD/manifest.cksum"
    [ -z "${extra:-}" ] || fail "malformed payload manifest"
    [ "$name" = "mib2q_android_auto_cluster.jar" ] || fail "unexpected payload name $name"
    [ "$(sum_of "$NEW")" = "$crc $bytes" ] || fail "payload checksum mismatch"
}

preflight() {
    [ -d "$BASE" ] || fail "v5 Android Auto package is not installed at $BASE"
    profile=$(cat "$PROFILE" 2>/dev/null || echo missing)
    [ "$profile" = "mhi2q_kr_aug22_p1201_mu1201" ] || fail "requires exact MU1201 P1201 profile; found $profile"
    [ -f "$JAR" ] || fail "existing v5 JAR is missing at $JAR"
    [ -f "$BASE/libsq5_cluster_live.so" ] || fail "existing v5 cluster hook is missing"
    [ -f "$BASE/gal_startup.sh" ] || fail "existing v5 startup is missing"
}

state() {
    current=$(sum_of "$JAR")
    wanted=$(sum_of "$NEW")
    if [ -f "$BACKUP" ] && [ "$current" = "$wanted" ]; then
        echo INSTALLED
    elif [ -f "$BACKUP" ] && [ "$current" = "$V1_JAR_SUM" ]; then
        echo V1_INSTALLED
    elif [ -f "$BACKUP" ]; then
        echo INCONSISTENT
    else
        echo NOT_INSTALLED
    fi
}

audit() {
    echo "MU1201 v5 KakaoNavi dropout hotfix - audit"
    echo "  profile:       $(cat "$PROFILE" 2>/dev/null || echo missing)"
    echo "  current JAR:   $(sum_of "$JAR")"
    echo "  payload JAR:   $(sum_of "$NEW")"
    echo "  backup JAR:    $(sum_of "$BACKUP")"
    echo "  hotfix state:  $(state)"
}

write_status() {
    {
        echo "profile=$(cat "$PROFILE" 2>/dev/null || echo missing)"
        echo "current=$(sum_of "$JAR")"
        echo "payload=$(sum_of "$NEW")"
        echo "backup=$(sum_of "$BACKUP")"
        echo "state=$(state)"
    } > "$LOG" 2>/dev/null || true
}

install_fix() {
    verify_payload
    preflight
    s=$(state)
    [ "$s" != INSTALLED ] || { echo "ALREADY INSTALLED. Remove the install marker and reboot if needed."; return; }
    [ "$s" != INCONSISTENT ] || fail "backup exists but live JAR changed; refusing to overwrite"
    if [ "$s" = V1_INSTALLED ]; then
        [ "$(sum_of "$BACKUP")" = "$V5_JAR_SUM" ] || fail "v1 backup is not the MU1201 v5 JAR; refusing to upgrade"
        remount_rw /mnt/app || fail "remount /mnt/app read-write"
        trap 'remount_ro /mnt/app || true' 0
        put "$NEW" "$JAR" 644 || fail "install corrected MU1201 JAR"
        sync_all
        remount_ro /mnt/app || true
        trap - 0
        echo "INSTALLED (upgraded from v1; the original v5 backup is kept). Remove kakao_dropout_fix_install from the SD root and reboot the MMI."
        echo "Emergency off: create mib2q_aa_off on the SD root and reboot."
        return
    fi
    [ "$(sum_of "$JAR")" = "$V5_JAR_SUM" ] || fail "live JAR is not the MU1201 v5 JAR ($(sum_of "$JAR")); refusing to overwrite"
    [ ! -e "$BACKUP_DIR" ] || fail "unexpected backup path already exists"

    remount_rw /mnt/app || fail "remount /mnt/app read-write"
    trap 'remount_ro /mnt/app || true' 0
    mkdir -p "$BACKUP_DIR" || fail "create backup directory"
    cp -p "$JAR" "$BACKUP" || fail "backup current v5 JAR"
    sum_of "$BACKUP" > "$BACKUP_DIR/original.cksum" || fail "record backup checksum"
    put "$NEW" "$JAR" 644 || fail "install corrected MU1201 JAR"
    sync_all
    remount_ro /mnt/app || true
    trap - 0
    echo "INSTALLED. Remove kakao_dropout_fix_install from the SD root and reboot the MMI."
    echo "Emergency off: create mib2q_aa_off on the SD root and reboot."
}

remove_fix() {
    verify_payload
    preflight
    [ -f "$BACKUP" ] || fail "no hotfix backup exists"
    current=$(sum_of "$JAR"); wanted=$(sum_of "$NEW"); original=$(sum_of "$BACKUP")
    [ "$current" = "$wanted" ] || [ "$current" = "$original" ] || [ "$current" = "$V1_JAR_SUM" ]         || fail "live JAR changed after install; refusing to overwrite"

    remount_rw /mnt/app || fail "remount /mnt/app read-write"
    trap 'remount_ro /mnt/app || true' 0
    put "$BACKUP" "$JAR" 644 || fail "restore original v5 JAR"
    rm -f "$BACKUP_DIR/original.cksum" "$BACKUP"
    rmdir "$BACKUP_DIR" 2>/dev/null || fail "backup directory contains unexpected files"
    sync_all
    remount_ro /mnt/app || true
    trap - 0
    echo "REMOVED. Remove kakao_dropout_fix_remove from the SD root and reboot the MMI."
}

collect_logs() {
    tmp=$(rooted /tmp)
    stamp=$(date +%Y%m%d_%H%M%S 2>/dev/null || echo unknown)
    run=$SD/mib2q-aa-logs/kakao-fix-$stamp-$$
    count=0
    mkdir -p "$run" 2>/dev/null || return 0
    for src in "$tmp"/sq5_aa.log "$tmp"/carplay_java.log "$tmp"/mib2q_aa_launcher.log "$tmp"/mib2q_aa_startup.log                "$tmp"/sq5_cluster_player.log "$tmp"/sq5_luka_wrapper.log "$tmp"/maneuver_render.log                "$tmp"/sq5_cluster_live-hook-*.log "$tmp"/sq5_cluster_ready "$tmp"/sq5_cluster_view; do
        [ -f "$src" ] || continue
        cp "$src" "$run/${src##*/}" 2>/dev/null && count=$((count+1))
    done
    { echo "logs=$count"; echo "date=$(date 2>/dev/null)"; audit; } > "$run/status.txt" 2>/dev/null
    echo "Saved $count log(s) to $run"
}

audit
collect_logs
if [ -f "$SD/kakao_dropout_fix_install" ] && [ -f "$SD/kakao_dropout_fix_remove" ]; then
    fail "both action markers are present; keep only one"
elif [ -f "$SD/kakao_dropout_fix_install" ]; then
    install_fix
elif [ -f "$SD/kakao_dropout_fix_remove" ]; then
    remove_fix
else
    echo "AUDIT ONLY: no head-unit files were modified."
fi
write_status
