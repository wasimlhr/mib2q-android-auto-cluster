# MU1201 v5 KakaoNavi cockpit dropout hotfix v2

This is a **narrow update for an existing MU1201 v5 installation**. It is not a
fresh v5 installer and it is not the earlier MU0918 LuKa package. It replaces
hotfix v1 and can be installed over it.

Exact target: `MHI2Q_KR_AUG22_P1201` / profile
`mhi2q_kr_aug22_p1201_mu1201`.

## The problem

With a KakaoNavi route active, the cockpit map kept dropping to the Audi map or
a grey screen, then coming back, roughly every 7 seconds. It happened mostly while
parked or stopped. KakaoNavi draws a still, whole-route map on the cockpit, so the
phone sends new cockpit frames only rarely. The cockpit treated three seconds
without a new frame as a dead stream and switched back to the Audi map.

## What changed

- **Main fix:** the cockpit keeps the Android Auto map through up to 8 seconds
  without a new frame (previously 3 seconds). The cockpit player still releases
  the map after 5 seconds without any frame, so a real stop still falls back
  within about 5 seconds.
- Keeps the current cockpit map through one or two failed reads of the
  cockpit-player status file (from v1).
- Requires three consecutive context mismatches before the cockpit is switched
  back to Android Auto (from v1).
- Every run of the script now saves logs, including the Java log
  `sq5_aa.log`, to `mib2q-aa-logs/` on the SD card.
- The installer refuses to run unless the head unit currently has the MU1201 v5
  Android Auto JAR or the v1 hotfix JAR.
- Replaces only `/mnt/app/eso/hmi/lsd/jars/mib2q_android_auto_cluster.jar`.
  The original v5 JAR is backed up and can be restored by this package.
- Keeps the `mib2q_aa_off` emergency switch.

This package does **not** change KakaoNavi's map view (north-up whole-route
overview). That view is drawn by KakaoNavi on the phone, and the head unit
cannot rotate it or make it follow the car.

## Install

1. Extract the ZIP.
2. Copy the included `mod` folder onto the M.I.B. SD card, replacing the card's
   current `mod` folder contents for this run.
3. First run: with no marker present, choose M.I.B. -> Advanced settings ->
   **Run custom script**. It runs a read-only check and saves logs. Confirm the screen shows
   profile `mhi2q_kr_aug22_p1201_mu1201` and no failure.
4. Create an empty file named `kakao_dropout_fix_install` in the SD-card root.
5. Run **Run custom script** again. It must print `INSTALLED`.
6. Remove `kakao_dropout_fix_install` from the SD card and reboot the MMI.

If anything is wrong, create `mib2q_aa_off` in the SD-card root and reboot. This
disables the Android Auto cockpit package for that boot.

## Test drive and logs

Park with a KakaoNavi route active for about two minutes, then drive. Before
switching the car off, run **Run custom script** with no marker present. It
saves the logs under `mib2q-aa-logs/kakao-fix-*` on the SD card. Zip that folder
and share it.

## Roll back

1. Create an empty file named `kakao_dropout_fix_remove` in the SD-card root.
2. Run **Run custom script**.
3. Remove the marker and reboot the MMI.

The remover restores the exact v5 JAR backed up during installation and refuses
to overwrite a JAR changed later by another tool.

To remove Android Auto completely, run this hotfix's rollback **first**, then
the v5 card's `mib2q_aa_uninstall`. Otherwise the hotfix backup folder is left
behind in `/mnt/app/root/sq5_android_auto`.

---

# MU1201 v5 KakaoNavi 콕핏 끊김 핫픽스 v2

기존 **MU1201 v5 설치용 소규모 업데이트**입니다. 신규 설치 패키지가
아니며, MU0918 LuKa 패키지도 아닙니다. 핫픽스 v1을 대체하며 v1 위에
그대로 설치할 수 있습니다.

## 문제

KakaoNavi 경로 안내 중 콕핏 지도가 약 7초마다 아우디 지도나 회색 화면으로
바뀌었다가 돌아왔습니다(주로 정차 중). KakaoNavi는 콕핏에 움직이지 않는
전체 경로 지도를 그리기 때문에 휴대폰이 새 화면을 거의 보내지 않고,
콕핏은 3초 동안 새 화면이 없으면 끊긴 것으로 보고 아우디 지도로
되돌아갔습니다.

## 변경 내용

- **주요 수정:** 새 화면이 없어도 최대 8초까지 Android Auto 지도를
  유지합니다(기존 3초). 화면이 5초 이상 전혀 없으면 플레이어가 지도를
  해제하므로 실제 중단 시에는 약 5초 안에 기본 화면으로 돌아갑니다.
- 콕핏 플레이어 상태 파일을 1~2회 읽지 못해도 현재 지도를 유지합니다(v1).
- 콕핏 컨텍스트가 3회 연속 불일치할 때만 재전환합니다(v1).
- 스크립트를 실행할 때마다 Java 로그 `sq5_aa.log`를 포함한 로그를
  SD 카드의 `mib2q-aa-logs/`에 저장합니다.
- MU1201 v5 JAR 또는 v1 핫픽스 JAR가 설치된 경우에만 설치합니다.
- `/mnt/app/eso/hmi/lsd/jars/mib2q_android_auto_cluster.jar` 하나만 교체하며,
  기존 v5 JAR은 백업되어 이 패키지로 복원할 수 있습니다.
- `mib2q_aa_off` 긴급 비활성화 기능은 그대로 유지됩니다.

KakaoNavi 지도 방향(북쪽 고정 전체 경로)은 휴대폰의 KakaoNavi가 그리므로
헤드유닛에서 회전하거나 차량 추적으로 바꿀 수 없습니다.

## 설치

1. ZIP 압축을 풉니다.
2. 포함된 `mod` 폴더를 M.I.B. SD 카드에 복사합니다.
3. 마커 없이 M.I.B. -> Advanced settings -> **Run custom script**를 실행합니다.
   읽기 전용 점검과 로그 저장만 합니다. `mhi2q_kr_aug22_p1201_mu1201`가
   표시되고 실패가 없는지 확인합니다.
4. SD 카드 루트에 빈 파일 `kakao_dropout_fix_install`을 만듭니다.
5. **Run custom script**를 다시 실행합니다. `INSTALLED`가 표시되어야 합니다.
6. 설치 마커를 삭제한 뒤 MMI를 재부팅합니다.

문제가 있으면 SD 카드 루트에 `mib2q_aa_off`를 만들고 재부팅하십시오.

## 테스트 주행과 로그

KakaoNavi 경로 안내를 켠 상태로 약 2분 정차한 뒤 주행합니다. 시동을 끄기
전에 마커 없이 **Run custom script**를 실행하면 SD 카드의
`mib2q-aa-logs/kakao-fix-*`에 로그가 저장됩니다. 해당 폴더를 압축해
공유해 주세요.

## 복원

1. SD 카드 루트에 빈 파일 `kakao_dropout_fix_remove`를 만듭니다.
2. **Run custom script**를 실행합니다.
3. 마커를 삭제한 뒤 MMI를 재부팅합니다.

Android Auto를 완전히 제거하려면 이 핫픽스 복원을 **먼저** 실행한 뒤
v5 카드의 `mib2q_aa_uninstall`을 실행하십시오.
