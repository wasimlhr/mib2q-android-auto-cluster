#!/bin/sh
# M.I.B. release builds execute command.sh; current builds execute custom.sh.
case ${0##*/} in
    command.sh) exec /bin/sh "${0%/*}/custom.sh" "$@" ;;
esac
