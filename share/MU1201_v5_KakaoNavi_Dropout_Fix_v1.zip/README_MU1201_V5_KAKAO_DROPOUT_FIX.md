# MU1201 v5 KakaoNavi cockpit dropout hotfix

This is a **narrow update for an existing MU1201 v5 installation**. It is not a
fresh v5 installer and it is not the earlier MU0918 LuKa package.

Exact target: `MHI2Q_KR_AUG22_P1201` / profile
`mhi2q_kr_aug22_p1201_mu1201`.

## What changed

- Keeps the current cockpit map through one or two transient mirror-marker read
  failures. Three consecutive misses (about 750 ms) are required before fallback.
- Requires three consecutive physical context mismatches before the cockpit is
  bounced back to the Android Auto context.
- Preserves the existing `mib2q_aa_off` emergency switch.
- Replaces only `/mnt/app/eso/hmi/lsd/jars/mib2q_android_auto_cluster.jar`.
  The previous v5 JAR is backed up and can be restored by the same package.

This package does **not** change KakaoNavi's own north-up/heading-up camera mode.

## Install

1. Extract the ZIP.
2. Copy the included `mod` folder onto the M.I.B. SD card, replacing the card's
   current `mod` folder contents for this run.
3. First run: with no marker present, choose M.I.B. -> Advanced settings ->
   **Run custom script**. It performs a read-only audit. Confirm the screen shows
   profile `mhi2q_kr_aug22_p1201_mu1201` and no failure.
4. Create an empty file named `kakao_dropout_fix_install` in the SD-card root.
5. Run **Run custom script** again. It must print `INSTALLED`.
6. Remove `kakao_dropout_fix_install` from the SD card and reboot the MMI.

If anything is wrong, create `mib2q_aa_off` in the SD-card root and reboot. This
disables the Android Auto cockpit package for that boot.

## Roll back

1. Create an empty file named `kakao_dropout_fix_remove` in the SD-card root.
2. Run **Run custom script**.
3. Remove the marker and reboot the MMI.

The remover restores the exact JAR backed up during installation and refuses to
overwrite a JAR changed later by another tool.

---

# MU1201 v5 KakaoNavi 콕핏 끊김 핫픽스

이 패키지는 **기존 MU1201 v5 설치용 소규모 업데이트**입니다. 신규 v5
설치 패키지가 아니며, 이전의 MU0918 LuKa 패키지도 아닙니다.

정확한 대상: `MHI2Q_KR_AUG22_P1201` / 프로필
`mhi2q_kr_aug22_p1201_mu1201`.

## 변경 내용

- 미러 상태 파일을 1~2회 일시적으로 읽지 못해도 현재 콕핏 지도를 유지합니다.
  3회 연속 실패(약 750 ms) 후에만 기본 화면으로 돌아갑니다.
- 실제 콕핏 컨텍스트가 3회 연속 불일치할 때만 Android Auto 화면으로
  재전환합니다.
- 기존 `mib2q_aa_off` 긴급 비활성화 기능을 유지합니다.
- `/mnt/app/eso/hmi/lsd/jars/mib2q_android_auto_cluster.jar` 하나만
  교체하며, 기존 v5 JAR은 백업되어 동일 패키지로 복원할 수 있습니다.

이 패키지는 KakaoNavi 자체의 북쪽 고정/진행 방향 고정 카메라 모드는
변경하지 않습니다.

## 설치

1. ZIP 압축을 풉니다.
2. 포함된 `mod` 폴더를 M.I.B. SD 카드에 복사합니다.
3. 마커 파일 없이 M.I.B. -> Advanced settings -> **Run custom script**를
   실행합니다. 읽기 전용 점검만 수행합니다. 화면에
   `mhi2q_kr_aug22_p1201_mu1201`가 표시되고 실패가 없는지 확인합니다.
4. SD 카드 루트에 빈 파일 `kakao_dropout_fix_install`을 만듭니다.
5. **Run custom script**를 다시 실행합니다. `INSTALLED`가 표시되어야 합니다.
6. SD 카드에서 설치 마커를 삭제한 뒤 MMI를 재부팅합니다.

문제가 있으면 SD 카드 루트에 `mib2q_aa_off`를 만들고 재부팅하십시오.

## 복원

1. SD 카드 루트에 빈 파일 `kakao_dropout_fix_remove`를 만듭니다.
2. **Run custom script**를 실행합니다.
3. 마커를 삭제한 뒤 MMI를 재부팅합니다.

제거 스크립트는 설치 때 백업한 정확한 JAR을 복원하며, 이후 다른 도구가
JAR을 변경한 경우에는 덮어쓰지 않고 중단합니다.
