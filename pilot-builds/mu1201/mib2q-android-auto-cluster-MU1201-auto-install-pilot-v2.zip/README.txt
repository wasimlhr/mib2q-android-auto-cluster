MU1201 CONTROLLED PILOT - Android Auto cluster/HUD path only.
Copy this folder's contents into the M.I.B. SD-card root.
Run the custom script once. It verifies the payload plus the unit's exact gal,
libautoreceiver.so and lsd.jxe fingerprints, then installs in the same run.
No install marker is required. Unknown or partially matching firmware is refused
before any filesystem is remounted read-write.
The experimental external-amplifier 5.1/upmix driver path is not part of this pilot.
Create mib2q_aa_uninstall instead to restore the saved configuration.
Rerunning the custom script saves current Android Auto logs under mib2q-aa-logs on the SD card.
